


<?php $__env->startSection('content'); ?>
<div class="container">
<div class="d-flex justify-content-between align-items-center mb-3">
    <h1>Blogs</h1>
    <a href="<?php echo e(route('blogs.create')); ?>" class="btn btn-primary">Add Blog</a>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('blog-table')->html();
} elseif ($_instance->childHasBeenRendered('xMupakE')) {
    $componentId = $_instance->getRenderedChildComponentId('xMupakE');
    $componentTag = $_instance->getRenderedChildComponentTagName('xMupakE');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('xMupakE');
} else {
    $response = \Livewire\Livewire::mount('blog-table');
    $html = $response->html();
    $_instance->logRenderedChild('xMupakE', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\work\furni-backend\resources\views/admin/blogs/index.blade.php ENDPATH**/ ?>