<div>
    <input
        type="text"
        wire:model.debounce.300ms="search"
        placeholder="Search blogs..."
        class="form-control mb-3"
    />

    <table class="table table-bordered table-hover ">
        <thead class="table-dark">
            <tr>
                <th>Image</th>
                <th>Title</th>
                <th>Excerpt</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <?php if($blog->image): ?>
                            <img src="<?php echo e(asset('storage/' . $blog->image)); ?>"
                                 alt="Blog Image"
                                 style="width: 120px; height: 80px; object-fit: cover; border-radius: 6px;">
                        <?php else: ?>
                            <img src="<?php echo e(asset('images/default-blog.jpg')); ?>"
                                 alt="Default"
                                 style="width: 120px; height: 80px; object-fit: cover; border-radius: 6px;">
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($blog->title); ?></td>
                    <td><?php echo e($blog->excerpt); ?></td>
                    <td class="text-center">
                        <!-- Edit button -->
                        <a href="<?php echo e(route('blogs.edit', $blog)); ?>"
                           class="btn btn-sm btn-outline-info"
                           title="Edit">
                            <i class="fa-solid fa-pen-to-square"></i>
                        </a>

                        <!-- Delete button with confirmation -->
                        <form action="<?php echo e(route('blogs.destroy', $blog)); ?>"
                              method="POST"
                              class="d-inline"
                              onsubmit="return confirm('Are you sure you want to delete this blog?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit"
                                    class="btn btn-sm btn-outline-danger"
                                    title="Delete">
                                <i class="fa-solid fa-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4">No blogs found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <?php echo e($blogs->links()); ?>

</div>
<?php /**PATH C:\Users\LENOVO\Desktop\work\furni-backend\resources\views/livewire/blog-table.blade.php ENDPATH**/ ?>