<div>
    <!-- Search bar -->
    <input type="text" wire:model.debounce.300ms="search" 
           placeholder="Search products..." 
           class="form-control mb-3" />

    <table class="table table-bordered align-middle">
        <thead>
            <tr>
                <th>#</th>
                <th>Image</th>
                <th>Name</th>
                <th>Price</th>
                <th>Stock</th>
                <th>Active</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($product->id); ?></td>
                <td>
                    <?php if($product->image): ?>
                        <img src="<?php echo e(asset('storage/' . $product->image)); ?>" 
                             alt="<?php echo e($product->name); ?>" 
                             style="width: 60px; height: 60px; object-fit: cover;">
                    <?php else: ?>
                        <span class="text-muted">No Image</span>
                    <?php endif; ?>
                </td>
                <td><?php echo e($product->name); ?></td>
                <td>$<?php echo e(number_format($product->price, 2)); ?></td>
                <td><?php echo e($product->stock); ?></td>
                <td><?php echo e($product->active ? 'Yes' : 'No'); ?></td>
                <td>
                    <a href="<?php echo e(route('products.edit', $product)); ?>" class="btn btn-sm btn-warning">Edit</a>
                    <form action="<?php echo e(route('products.destroy', $product)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger" onclick="return confirm('Delete this product?')">
                            Delete
                        </button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center text-muted">No products found</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <?php echo e($products->links()); ?>

</div>
<?php /**PATH C:\Users\LENOVO\Desktop\work\furni-backend\resources\views/livewire/product-table.blade.php ENDPATH**/ ?>