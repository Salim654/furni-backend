
<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
<h1>Orders</h1>


<div class="mb-3">
    <form method="GET" class="d-flex gap-2">
        <select name="status" class="form-select" style="max-width: 200px;">
            <option value="">All Status</option>
            <option value="pending" <?php echo e(request('status')=='pending' ? 'selected' : ''); ?>>Pending</option>
            <option value="processing" <?php echo e(request('status')=='processing' ? 'selected' : ''); ?>>Processing</option>
            <option value="completed" <?php echo e(request('status')=='completed' ? 'selected' : ''); ?>>Completed</option>
            <option value="cancelled" <?php echo e(request('status')=='cancelled' ? 'selected' : ''); ?>>Cancelled</option>
        </select>
        <button type="submit" class="btn btn-primary">Filter</button>
    </form>
</div>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>#</th>
            <th>Customer</th>
            <th>Total</th>
            <th>Promo Code</th>
            <th>Status</th>
            <th>Date</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($order->id); ?></td>
            <td><?php echo e($order->user->name); ?></td>
            <td>$<?php echo e(number_format($order->total, 2)); ?></td>
            <td><?php echo e($order->promo ? $order->promo->code : '-'); ?></td>

            <td>
                <span class="badge bg-<?php echo e($order->status == 'pending' ? 'warning' : ($order->status == 'completed' ? 'success' : ($order->status == 'processing' ? 'info' : 'danger'))); ?>">
                    <?php echo e(ucfirst($order->status)); ?>

                </span>
            </td>
            <td><?php echo e($order->created_at->format('Y-m-d')); ?></td>
            <td>
                <a href="<?php echo e(route('orders.show', $order)); ?>" class="btn btn-sm btn-info">View</a>
                <a href="<?php echo e(route('orders.edit', $order)); ?>" class="btn btn-sm btn-warning">Edit</a>
                <form action="<?php echo e(route('orders.destroy', $order)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-sm btn-danger" onclick="return confirm('Delete this order?')">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php echo e($orders->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\work\furni-backend\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>