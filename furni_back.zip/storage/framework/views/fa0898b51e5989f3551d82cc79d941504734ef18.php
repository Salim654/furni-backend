<div>
    <table class="table table-bordered">
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>From</th>
                <th>Email</th>
                <th>Message</th>
                <th>Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($msg->id); ?></td>
                    <td><?php echo e($msg->first_name); ?> <?php echo e($msg->last_name); ?></td>
                    <td><?php echo e($msg->email); ?></td>
                    <td><?php echo e(Str::limit($msg->message, 50)); ?></td>
                    <td><?php echo e($msg->created_at->format('d M Y, H:i')); ?></td>
                    <td class="text-center">
                        <!-- Edit button -->
                        <a href="<?php echo e(route('messages.edit', $msg->id)); ?>" 
                            class="btn btn-sm btn-outline-info"
                           title="Edit">
                            <i class="fa-solid fa-pen-to-square"></i>
                        </a>

                        <!-- Delete button with confirm -->
                        <button 
                            onclick="if(confirm('Are you sure you want to delete this message?')) { window.livewire.find('<?php echo e($_instance->id); ?>').call('delete', <?php echo e($msg->id); ?>) }"
                            class="btn btn-sm btn-outline-danger"
                            title="Delete">
                           <i class="fa-solid fa-trash"></i>
                        </button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6">No messages found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <?php echo e($messages->links()); ?>

</div>
<?php /**PATH C:\Users\LENOVO\Desktop\work\furni-backend\resources\views/livewire/message-table.blade.php ENDPATH**/ ?>