

<?php $__env->startSection('title', 'Products'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
<div class="d-flex justify-content-between align-items-center mb-3">
    <h1>Products</h1>
    <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary">Add Product</a>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('product-table')->html();
} elseif ($_instance->childHasBeenRendered('HbYIekE')) {
    $componentId = $_instance->getRenderedChildComponentId('HbYIekE');
    $componentTag = $_instance->getRenderedChildComponentTagName('HbYIekE');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('HbYIekE');
} else {
    $response = \Livewire\Livewire::mount('product-table');
    $html = $response->html();
    $_instance->logRenderedChild('HbYIekE', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\work\furni-backend\resources\views/admin/products/index.blade.php ENDPATH**/ ?>