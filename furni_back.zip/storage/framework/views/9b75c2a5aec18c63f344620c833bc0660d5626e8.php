

<?php $__env->startSection('title', 'Promo Codes'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
     <h1>Promo Codes</h1>
    <a href="<?php echo e(route('promos.create')); ?>" class="btn btn-primary">Add Promo</a>
</div>


    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('promo-table')->html();
} elseif ($_instance->childHasBeenRendered('XcWPpCG')) {
    $componentId = $_instance->getRenderedChildComponentId('XcWPpCG');
    $componentTag = $_instance->getRenderedChildComponentTagName('XcWPpCG');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('XcWPpCG');
} else {
    $response = \Livewire\Livewire::mount('promo-table');
    $html = $response->html();
    $_instance->logRenderedChild('XcWPpCG', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\work\furni-backend\resources\views/admin/promos/index.blade.php ENDPATH**/ ?>