<div>
    <input
        type="text"
        wire:model.debounce.300ms="search"
        placeholder="Search promo codes..."
        class="form-control mb-3"
    />

    <table class="table table-bordered table-hover">
        <thead>
            <tr>
                <th>Code</th>
                <th>Type</th>
                <th>Value</th>
                <th>Active</th>
                <th>Starts At</th>
                <th>Ends At</th>
                <th>Usage Limit</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $promos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($promo->code); ?></td>
                    <td><?php echo e(ucfirst($promo->type)); ?></td>
                    <td><?php echo e($promo->value); ?></td>
                    <td><?php echo e($promo->active ? 'Yes' : 'No'); ?></td>
                    <td><?php echo e($promo->starts_at?->format('Y-m-d') ?? '-'); ?></td>
                    <td><?php echo e($promo->ends_at?->format('Y-m-d') ?? '-'); ?></td>
                    <td><?php echo e($promo->usage_limit ?? '-'); ?></td>
                    <td class="text-center">
                        
                        <a href="<?php echo e(route('promos.edit', $promo)); ?>" 
                           class="btn btn-sm btn-outline-info"
                           title="Edit">
                            <i class="fa-solid fa-pen-to-square"></i>
                        </a>

                        
                        <form
                            action="<?php echo e(route('promos.destroy', $promo)); ?>"
                            method="POST"
                            style="display:inline-block"
                            onsubmit="return confirm('Are you sure you want to delete this promo?');"
                        >
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-outline-danger" title="Delete">
                                <i class="fa-solid fa-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8">No promo codes found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <?php echo e($promos->links()); ?>

</div>
<?php /**PATH C:\Users\LENOVO\Desktop\work\furni-backend\resources\views/livewire/promo-table.blade.php ENDPATH**/ ?>