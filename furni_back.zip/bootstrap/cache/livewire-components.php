<?php return array (
  'blog-table' => 'App\\Http\\Livewire\\BlogTable',
  'message-table' => 'App\\Http\\Livewire\\MessageTable',
  'orders-table' => 'App\\Http\\Livewire\\OrdersTable',
  'product-table' => 'App\\Http\\Livewire\\ProductTable',
  'promo-table' => 'App\\Http\\Livewire\\PromoTable',
);