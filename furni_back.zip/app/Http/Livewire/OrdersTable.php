<?php

namespace App\Http\Livewire;

use Livewire\Component;
use Livewire\WithPagination;
use App\Models\Order;

class OrdersTable extends Component
{
    use WithPagination;

    public $status = '';

    protected $updatesQueryString = ['status'];

    public function updatingStatus()
    {
        $this->resetPage(); // reset to page 1 when filtering
    }

    public function render()
    {
        $query = Order::with(['user', 'promo'])
            ->when($this->status, function ($q) {
                $q->where('status', $this->status);
            })
            ->latest();

        return view('livewire.orders-table', [
            'orders' => $query->paginate(5),
        ]);
    }
}
