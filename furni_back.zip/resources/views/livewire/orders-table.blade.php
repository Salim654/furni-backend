<div>
    <table class="table table-bordered table-hover align-middle text-center">
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>Customer</th>
                <th>Totavxcvl</th>
                <th>Proxcvxcmo Code</th>
                <th>Stxcvxcatus</th>
                <th>Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @forelse($orders as $order)
                <tr wire:key="order-{{ $order->id }}">
                    <td>{{ $order->id }}</td>
                    <td>{{ $order->user->name }}</td>
                    <td>${{ number_format($order->total, 2) }}</td>
                    <td>{{ $order->promo ? $order->promo->code : '-' }}</td>
                    <td>
                        <span class="badge bg-{{ $order->status == 'pending' ? 'warning' : ($order->status == 'completed' ? 'success' : ($order->status == 'processing' ? 'info' : 'danger')) }}">
                            {{ ucfirst($order->status) }}
                        </span>
                    </td>
                    <td>{{ $order->created_at->format('Y-m-d') }}</td>
                    <td class="text-center d-inline-flex gap-2">
                        <!-- View -->
                        <a href="{{ route('orders.show', $order) }}"
                           class="btn btn-sm btn-outline-primary"
                           title="View">
                            <i class="fa-solid fa-eye"></i>
                        </a>

                        <!-- Edit -->
                        <a href="{{ route('orders.edit', $order) }}"
                           class="btn btn-sm btn-outline-info"
                           title="Edit">
                            <i class="fa-solid fa-pen-to-square"></i>
                        </a>

                        <!-- Delete with confirm -->
                        <form action="{{ route('orders.destroy', $order) }}"
                              method="POST"
                              class="d-inline"
                              onsubmit="return confirm('Are you sure you want to delete this order?');">
                            @csrf
                            @method('DELETE')
                            <button type="submit"
                                    class="btn btn-sm btn-outline-danger"
                                    title="Delete">
                                <i class="fa-solid fa-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="7" class="text-center">No orders found</td>
                </tr>
            @endforelse
        </tbody>
    </table>

    {{ $orders->links() }}
</div>
