@extends('layouts.admin')
@section('title', 'Orders')

@section('content')
<div class="container">
<h1>Orders</h1>

{{-- Filter --}}
<div class="mb-3">
    <form method="GET" class="d-flex gap-2">
        <select name="status" class="form-select" style="max-width: 200px;">
            <option value="">All Status</option>
            <option value="pending" {{ request('status')=='pending' ? 'selected' : '' }}>Pending</option>
            <option value="processing" {{ request('status')=='processing' ? 'selected' : '' }}>Processing</option>
            <option value="completed" {{ request('status')=='completed' ? 'selected' : '' }}>Completed</option>
            <option value="cancelled" {{ request('status')=='cancelled' ? 'selected' : '' }}>Cancelled</option>
        </select>
        <button type="submit" class="btn btn-primary">Filter</button>
    </form>
</div>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>#</th>
            <th>Customer</th>
            <th>Total</th>
            <th>Promo Code</th>
            <th>Status</th>
            <th>Date</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        @foreach($orders as $order)
        <tr>
            <td>{{ $order->id }}</td>
            <td>{{ $order->user->name }}</td>
            <td>${{ number_format($order->total, 2) }}</td>
            <td>{{ $order->promo ? $order->promo->code : '-' }}</td>

            <td>
                <span class="badge bg-{{ $order->status == 'pending' ? 'warning' : ($order->status == 'completed' ? 'success' : ($order->status == 'processing' ? 'info' : 'danger')) }}">
                    {{ ucfirst($order->status) }}
                </span>
            </td>
            <td>{{ $order->created_at->format('Y-m-d') }}</td>
            <td>
                <a href="{{ route('orders.show', $order) }}" class="btn btn-sm btn-info">View</a>
                <a href="{{ route('orders.edit', $order) }}" class="btn btn-sm btn-warning">Edit</a>
                <form action="{{ route('orders.destroy', $order) }}" method="POST" class="d-inline">
                    @csrf @method('DELETE')
                    <button class="btn btn-sm btn-danger" onclick="return confirm('Delete this order?')">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>

{{ $orders->links() }}
</div>
@endsection
