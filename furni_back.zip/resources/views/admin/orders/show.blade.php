@extends('layouts.admin')
@section('title', 'Order Details')

@section('content')
<div class="container">
<a href="{{ route('orders.index') }}" class="btn btn-dark mb-3">
    ←
</a>
<h3>Order #{{ $order->id }}</h3>
<p><strong>Customer:</strong> {{ $order->user->name }}</p>
<p><strong>Status:</strong> {{ ucfirst($order->status) }}</p>
@if($order->promo)
    <p><strong>Promo Code:</strong> {{ $order->promo->code }}</p>
    <p><strong>Promo Discount:</strong> ${{ number_format($order->discount, 2) }}</p>
@endif

<p><strong>Total:</strong> ${{ number_format($order->total, 2) }}</p>


<h5>Items:</h5>
<table class="table table-bordered">
    <thead>
        <tr>
            <th>Product</th>
            <th>Qty</th>
            <th>Price</th>
        </tr>
    </thead>
    <tbody>
        @foreach($order->items as $item)
        <tr>
            <td>{{ $item->product->name }}</td>
            <td>{{ $item->quantity }}</td>
            <td>${{ number_format($item->product->price, 2) }}</td>
        </tr>
        @endforeach
    </tbody>
</table>
</div>
@endsection
